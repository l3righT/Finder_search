import 'package:flutter/material.dart';
import 'package:finder_search/screens/Page_1.dart';

class pagetwo extends StatefulWidget {
  @override
  _pagetwoState createState() => _pagetwoState();
}

class _pagetwoState extends State<pagetwo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(




    );
  }
}
